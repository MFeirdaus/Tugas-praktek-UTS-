<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>medilak check form</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">MEDICAL FORM</h3></div>
                                    <div class="card-body">
                                        <form>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['inputFirstName']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['inputLastName']; ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                   <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['inputLastName']; ?>
                                                         </p>
                                                    </div>   
                                                </diV>
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['radio']; ?>
                                                         </p>
                                                    </div>
                                                </div>    
                                            </div> 
                                            <div class="row mb-3">
                                                <div class="col-md-12">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['inputEmail']; ?>
                                                         </p>
                                                    </div>
                                                </div> 
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['agama']; ?>
                                                         </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['pendidikan']; ?>
                                                         </p>
                                                    </div>
                                                </div>     
                                            </div> 
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['kota']; ?>
                                                         </p>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="border">
                                                        <p class="mt-2 ms-2">
                                                            <?php echo $_POST['provinsi']; ?>
                                                         </p>
                                                    </div>
                                                </div>
                                            </div>
                                         
                                            <!-- bawahnya -->


                                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">MEDICAL CHECK FORM</h3></div>
                                        <div class="card-body">
                                        <form>
                                            </form>
                                                <div class="row mb-3">
                                                    <div class="col-md-12">
                                                        <div class="form-floating mb-3 mb-md-0">
                                                            <div class="form-group row">
                                                                <label class="col-12">Periksa ketentuan yang berlaku untuk anda atau anggota kerabat dekat anda:</label> 
                                                                <div class="col-12">
                                                                    <div class="border">
                                                                        <p class="mt-2 ms-2">
                                                                            <?php echo $_POST['penyakit']; ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-floating">
                                                            <div class="form-group row">
                                                            <label class="col-12">Periksa gejala yang anda alami saat ini:</label> 
                                                                <div class="col-12">
                                                                    <div class="border">
                                                                        <p class="mt-2 ms-2">
                                                                            <?php echo $_POST['gejala']; ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-floating">
                                                            <div class="form-group row">
                                                            <label class="col-12">Apakah saat ini sedang mengkonsumsi obat?</label> 
                                                                <div class="col-12">
                                                                    <div class="border">
                                                                        <p class="mt-2 ms-2">
                                                                            <?php echo $_POST['obat']; ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-floating">
                                                            <div class="form-group row">
                                                            <label class="col-12">Silahkan list yang lain:</label> 
                                                                <div class="col-12">
                                                                    <div class="border">
                                                                        <p class="mt-2 ms-2">
                                                                            <?php echo $_POST['komentar']; ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Take care of your health</h3></div>
                                                <div class="card-body">                                          
                                            </form>
                                        </form>
                                    </div>                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; by feirdaus 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
