<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Register - SB Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">MEDICAL FORM</h3></div>
                                    <div class="card-body">
                                        <form action="check.php" method="POST">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="inputFirstName" type="text" placeholder="Enter your first name" />
                                                        <label for="inputFirstName">First name</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" name="inputLastName" type="text" placeholder="Enter your last name" />
                                                        <label for="inputLastName">Last name</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="inputage" type="number" placeholder="Enter your last name" />
                                                        <label for="inputLastN">what is your age?</label>
                                                    </div>
                                                </diV>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <div class="custom-control custom-radio custom-control-inline">
                                                            <input name="radio" id="radio_0" type="radio" class="custom-control-input" value="laki-laki"> 
                                                            <label for="radio_0" class="custom-control-label">laki-laki</label>
                                                        </div>
                                                        <div class="custom-control custom-radio custom-control-inline">
                                                            <input name="radio" id="radio_1" type="radio" class="custom-control-input" value="perempuan"> 
                                                            <label for="radio_1" class="custom-control-label">Perempuan</label>
                                                        </div>
                                                    </div>
                                                </div>    
                                            </div> 
                                            <div class="form-floating mb-3">
                                                <input class="form-control" name="inputEmail" type="email" placeholder="name@example.com" />
                                                <label for="inputEmail">Email</label>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <select name="agama" class="custom-select" required="required">
                                                            <option value="agama">Agama</option>
                                                            <option value="islam">Islam</option>
                                                            <option value="kristen">Kristen</option>
                                                            <option value="hindu">Hindu</option>
                                                            <option value="budha">Budha</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <select  name="pendidikan" class="custom-select" required="required">
                                                            <option value="jenjang pendidikan">Jenjang Pendidikan</option>
                                                            <option value="sd">SD</option>
                                                            <option value="smp">SMP</option>
                                                            <option value="sma">SMA</option>
                                                            <option value="d1">D1</option>
                                                            <option value="d2">D2</option>
                                                            <option value="d3">D3</option>
                                                            <option value="d4">D4</option>
                                                            <option value="s1">S1</option>
                                                            <option value="s2">S2</option>
                                                            <option value="s3">S3</option>
                                                        </select>
                                                    </div>
                                                </div>     
                                            </div> 
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" name="kota" type="text" placeholder="Nama kota" />
                                                        <label for="inputPassword">Nama Kota</label>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                            <select id="select" name="provinsi" class="custom-select" required="required">
                                                                <option value="Provinsi">Provinsi</option>
                                                                <option value="Jawa Timur">Jawa Timur</option>
                                                                <option value="Jawa Tengah">Jawa Tengah</option>
                                                                <option value="Jawa Barat">Jawa Barat</option>
                                                                <option value="DKI Jakarta">DKI Jakarta</option>
                                                                <option value="Aceh">Aceh</option>
                                                                <option value="Sumatera Utara">Sumatera Utara</option>
                                                                <option value="Sumatera Barat">Sumatera Barat</option>
                                                                <option value="Sumatera Selatan">Sumatera Selatan</option>
                                                                <option value="Jambi">Jambi</option>
                                                                <option value="Riau">Riau</option>
                                                                <option value="Bengkulu">Bengkulu</option>
                                                                <option value="Lampung">Lampung</option>
                                                                <option value="Kepulauan Bangka Belitung">Kepulauan Bangka Belitung</option>
                                                                <option value="Kepulauan Riau">Kepulauan Riau</option>
                                                                <option value="Banten">Banten</option>
                                                                <option value="Bali">Bali</option>
                                                                <option value="Nusa Tenggara Barat">Nusa Tenggara Barat</option>
                                                                <option value="Nusa Tenggara Timur">Nusa Tenggara Timur</option>
                                                                <option value="Kalimantan Barat">Kalimantan Barat</option>
                                                                <option value="Kalimantan Tengah">Kalimantan Tengah</option>
                                                                <option value="Kalimantan Selatan">Kalimantan Selatan</option>
                                                                <option value="Kalimantan Timur">Kalimantan Timur</option>
                                                                <option value="Kalimantan Utara">Kalimantan Utara</option>
                                                                <option value="Sulawesi Utara">Sulawesi Utara</option>
                                                                <option value="Sulawesi Tengah">Sulawesi Tengah</option>
                                                                <option value="Sulawesi Selatan">Sulawesi Selatan</option>
                                                                <option value="Sulawesi Tenggara">Sulawesi Tenggara</option>
                                                                <option value="Sulawesi Barat">Sulawesi Barat</option>
                                                                <option value="Gorontalo">Gorontalo</option>
                                                                <option value="Maluku">Maluku</option>
                                                                <option value="Maluku Utara">Maluku Utara</option>
                                                                <option value="Papua">Papua</option>
                                                                <option value="Papua Barat">Papua Barat</option>
                                                            </select>
                                                    </div>
                                                </div>
                                            </div>
                                         
                                            <!-- bawahnya -->

                                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                            <div class="card-header"><h3 class="text-center font-weight-light my-4">MEDICAL CHECK FORM</h3></div>
                                            <div class="card-body">
                                            <div class="row mb-3">
                                                <div class="col-md-12">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                    <div class="form-group row">
                                                        <label class="col-12">Periksa ketentuan yang berlaku untuk anda atau anggota kerabat dekat anda:</label> 
                                                            <div class="col-12">
                                                            <div class="custom-control custom-checkbox custom-control-inline">
                                                                <input name="penyakit" id="checkbox_0" type="checkbox" class="custom-control-input" value="asma"> 
                                                                <label for="checkbox_0" class="custom-control-label">Asma</label>
                                                            </div>
                                                            <div class="custom-control custom-checkbox custom-control-inline">
                                                                <input name="penyakit" id="checkbox_1" type="checkbox" class="custom-control-input" value="penyakit jantung"> 
                                                                <label for="checkbox_1" class="custom-control-label">Penyakit Jantung</label>
                                                            </div>
                                                            <div class="custom-control custom-checkbox custom-control-inline">
                                                                <input name="penyakit" id="checkbox_2" type="checkbox" class="custom-control-input" value="kanker"> 
                                                                <label for="checkbox_2" class="custom-control-label">Kanker</label>
                                                            </div>
                                                            <div class="custom-control custom-checkbox custom-control-inline">
                                                                <input name="penyakit" id="checkbox_3" type="checkbox" class="custom-control-input" value="diabetes"> 
                                                                <label for="checkbox_3" class="custom-control-label">Diabetes</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-floating">
                                                    <div class="form-group row">
                                                        <label class="col-12">Periksa gejala yang anda alami saat ini:</label> 
                                                            <div class="col-12">
                                                            <div class="custom-control custom-checkbox custom-control-inline">
                                                                <input name="gejala" id="checkbox1_0" type="checkbox" class="custom-control-input" value="sakit dada"> 
                                                                <label for="checkbox1_0" class="custom-control-label">Sakit Dada</label>
                                                            </div>
                                                            <div class="custom-control custom-checkbox custom-control-inline">
                                                                <input name="gejala" id="checkbox1_1" type="checkbox" class="custom-control-input" value="kardiovaskular"> 
                                                                <label for="checkbox1_1" class="custom-control-label">Kardiovaskular</label>
                                                            </div>
                                                            <div class="custom-control custom-checkbox custom-control-inline">
                                                                <input name="gejala" id="checkbox1_2" type="checkbox" class="custom-control-input" value="pernafasan"> 
                                                                <label for="checkbox1_2" class="custom-control-label">Pernafasan</label>
                                                            </div>
                                                            <div class="custom-control custom-checkbox custom-control-inline">
                                                                <input name="gejala" id="checkbox1_3" type="checkbox" class="custom-control-input" value="penambahan bb"> 
                                                                <label for="checkbox1_3" class="custom-control-label">Penambahan BB</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-12">Apakah saat ini sedang mengkonsumsi obat?</label> 
                                                <div class="col-12">
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="obat" id="radio_2" type="radio" class="custom-control-input" value="ya"> 
                                                    <label for="radio_2" class="custom-control-label">Ya</label>
                                                </div>
                                                <div class="custom-control custom-radio custom-control-inline">
                                                    <input name="obat" id="radio_3" type="radio" class="custom-control-input" value="tidak"> 
                                                    <label for="radio_3" class="custom-control-label">Tidak</label>
                                                 </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="textarea" class="col-12 col-form-label">Silahkan List yang lain:</label> 
                                                    <div class="col-12">
                                                        <textarea id="textarea" name="komentar" cols="40" rows="2" class="form-control"></textarea>
                                                    </div>
                                            </div> 
                                            <div class="form-group row">
                                                <div class="col-12">
                                                    <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>

            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; by feirdaus 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
